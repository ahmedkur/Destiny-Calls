
export default function Normal({ children }) {
  return (
    <>
      {/* <SmoothScroll style={{ height: '100vh', overflowY: 'auto' }}> */}
      {children}
      {/* </SmoothScroll> */}
    </>
  );
}
